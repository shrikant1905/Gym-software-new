import React, { useState, useEffect, useRef } from "react";
import { FaEye, FaEdit, FaTrashAlt, FaUser } from "react-icons/fa";
import axiosInstance from "../../Api/axiosInstance";
import ImageCropper from "../../Components/ImageCropper";
// 🔽 New imports for export
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';

const SuperAdminAdmin = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [modalType, setModalType] = useState("add");
  const [selectedAdmin, setSelectedAdmin] = useState(null);
  const [selectedAdminMembers, setSelectedAdminMembers] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingMembers, setLoadingMembers] = useState(false);

  const [plans, setPlans] = useState([]);
  const [loadingPlans, setLoadingPlans] = useState(true);

  const [branches, setBranches] = useState([]);
  const [loadingBranches, setLoadingBranches] = useState(true);

  // 🔁 FETCH ADMINS
  useEffect(() => {
    const fetchAdmins = async () => {
      try {
        const response = await axiosInstance.get("/auth/admins");
        if (response.data.success && Array.isArray(response.data.admins)) {
          setAdmins(response.data.admins);
        } else {
          setAdmins([]);
        }
      } catch (error) {
        console.error("Failed to fetch admins:", error);
        setAdmins([]);
        alert("Failed to load admin list.");
      } finally {
        setLoading(false);
      }
    };
    fetchAdmins();
  }, []);

  // 🔁 FETCH PLANS
  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const response = await axiosInstance.get("/plans");
        if (response.data.success && Array.isArray(response.data.plans)) {
          setPlans(response.data.plans);
        } else {
          setPlans([]);
        }
      } catch (error) {
        console.error("Failed to fetch plans:", error);
        setPlans([]);
        alert("Failed to load plans.");
      } finally {
        setLoadingPlans(false);
      }
    };
    fetchPlans();
  }, []);

  // 🔁 FETCH BRANCHES
  useEffect(() => {
    const fetchBranches = async () => {
      try {
        const response = await axiosInstance.get("/branches");
        if (response.data.success && Array.isArray(response.data.branches)) {
          setBranches(response.data.branches);
        } else {
          setBranches([]);
        }
      } catch (error) {
        console.error("Failed to fetch branches:", error);
        setBranches([]);
        alert("Failed to load branches.");
      } finally {
        setLoadingBranches(false);
      }
    };
    fetchBranches();
  }, []);

  // 🔁 LOAD RAZORPAY
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const getBranchNameById = (branchId) => {
    if (!branchId) return "Not Assigned";
    const branch = branches.find((b) => b.id === branchId);
    return branch ? branch.name : "Unknown Branch";
  };

  const handleAddNew = () => {
    setModalType("add");
    setSelectedAdmin(null);
    setIsModalOpen(true);
  };

  const handleView = (admin) => {
    setModalType("view");
    setSelectedAdmin(admin);
    setIsModalOpen(true);
  };

  const handleEdit = (admin) => {
    setModalType("edit");
    setSelectedAdmin(admin);
    setIsModalOpen(true);
  };

  const handleDeleteClick = (admin) => {
    setSelectedAdmin(admin);
    setIsDeleteModalOpen(true);
  };

  // 🔹 NEW: Fetch members and open modal
  const handleViewMembers = async (admin) => {
    setSelectedAdmin(admin);
    setLoadingMembers(true);
    setIsMemberModalOpen(true);
    try {
      const response = await axiosInstance.get(`/members/admin/${admin.id}`);
      if (response.data.success && Array.isArray(response.data.data)) {
        setSelectedAdminMembers(response.data.data);
      } else {
        setSelectedAdminMembers([]);
      }
    } catch (error) {
      console.error("Failed to fetch members:", error);
      alert("Failed to load members.");
      setSelectedAdminMembers([]);
    } finally {
      setLoadingMembers(false);
    }
  };

  // 🔹 EXPORT TO EXCEL
  const exportMembersToExcel = () => {
    if (!selectedAdminMembers.length) return;

    const worksheetData = selectedAdminMembers.map(member => ({
      'Name': member.fullName,
      'Phone': member.phone,
      'Email': member.email,
      'Gender': member.gender,
      'Plan ID': member.planId || '—',
      'Interested In': member.interestedIn || '—',
      'Join Date': member.joinDate ? new Date(member.joinDate).toLocaleDateString() : '—',
      'Status': member.status,
    }));

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Members");
    XLSX.writeFile(workbook, `Members_of_${selectedAdmin?.fullName || 'Admin'}.xlsx`);
  };

  // 🔹 EXPORT TO PDF
const exportMembersToPDF = async () => {
  if (!selectedAdminMembers.length) return;

  // Dynamically import autoTable only when needed
  const { default: autoTable } = await import('jspdf-autotable');

  const doc = new jsPDF();

  // ✅ Manually attach autoTable to this doc instance
  autoTable(doc, {
    startY: 30,
    head: [['Name', 'Phone', 'Email', 'Gender', 'Plan ID', 'Interested In', 'Join Date', 'Status']],
    body: selectedAdminMembers.map(member => [
      member.fullName,
      member.phone || '—',
      member.email || '—',
      member.gender || '—',
      member.planId || '—',
      member.interestedIn || '—',
      member.joinDate ? new Date(member.joinDate).toLocaleDateString() : '—',
      member.status || '—',
    ]),
    theme: 'grid',
    headStyles: { fillColor: [110, 178, 204] }, // #6EB2CC
    styles: { fontSize: 9, cellPadding: 3 },
  });

  const title = `Members of ${selectedAdmin?.fullName || 'Admin'}`;
  doc.setFontSize(16);
  const pageWidth = doc.internal.pageSize.getWidth();
  doc.text(title, pageWidth / 2, 20, { align: 'center' });

  doc.save(`${title.replace(/\s+/g, '_')}.pdf`);
};

  // 🔹 EXPORT ADMINS TO EXCEL
  const exportAdminsToExcel = () => {
    if (!admins.length) return;

    const worksheetData = admins.map(admin => ({
      'Admin Name': admin.fullName,
      'Email': admin.email,
      'Subscription': admin.subscriptionPlan || '—',
      'Expiry Date': admin.licenseExpiryDate ? new Date(admin.licenseExpiryDate).toLocaleDateString() : 'Not Set',
      'Gym Name': admin.gymName || '—',
      'GST Number': admin.gstNumber || '—',
      'Tax Rate': `${admin.tax || '18'}%`,
      'Contact': admin.phone || '—',
      'Status': admin.status,
    }));

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Gym Owners");
    XLSX.writeFile(workbook, "Gym_Owners_List.xlsx");
  };

  // 🔹 EXPORT ADMINS TO PDF
  const exportAdminsToPDF = async () => {
    if (!admins.length) return;

    const { default: autoTable } = await import('jspdf-autotable');
    const doc = new jsPDF('landscape');

    // Add Title
    doc.setFontSize(16);
    doc.text("Gym Owners (Admin) Management List", 14, 15);
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 22);

    autoTable(doc, {
      startY: 28,
      head: [['Admin Name', 'Email', 'Subscription', 'Expiry Date', 'Gym Name', 'GST', 'Tax', 'Contact', 'Status']],
      body: admins.map(admin => [
        admin.fullName,
        admin.email,
        admin.subscriptionPlan || '—',
        admin.licenseExpiryDate ? new Date(admin.licenseExpiryDate).toLocaleDateString() : 'Not Set',
        admin.gymName || '—',
        admin.gstNumber || '—',
        `${admin.tax || '18'}%`,
        admin.phone || '—',
        admin.status
      ]),
      styles: { fontSize: 8 },
      headStyles: { fillColor: [40, 167, 69] }
    });

    doc.save("Gym_Owners_List.pdf");
  };

  const confirmDelete = async () => {
    if (selectedAdmin) {
      try {
        const response = await axiosInstance.delete(
          `/auth/user/${selectedAdmin.id}`
        );
        if (response.data.success) {
          setAdmins(admins.filter((admin) => admin.id !== selectedAdmin.id));
          alert(`Admin "${selectedAdmin.fullName}" has been deleted successfully.`);
        } else {
          throw new Error("Failed to delete admin");
        }
      } catch (error) {
        console.error("Error deleting admin:", error);
        alert("Failed to delete admin. Please try again.");
      } finally {
        setIsDeleteModalOpen(false);
        setSelectedAdmin(null);
      }
    }
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedAdmin(null);
  };

  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setSelectedAdmin(null);
  };

  const closeMemberModal = () => {
    setIsMemberModalOpen(false);
    setSelectedAdmin(null);
    setSelectedAdminMembers([]);
  };

  useEffect(() => {
    document.body.style.overflow = isModalOpen || isDeleteModalOpen || isMemberModalOpen ? "hidden" : "unset";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [isModalOpen, isDeleteModalOpen, isMemberModalOpen]);

  const getStatusBadge = (status) => {
    const normalized = (status || "inactive").toLowerCase();
    return (
      <span
        className="badge rounded-pill px-2 py-1 d-inline-block"
        style={{
          backgroundColor: normalized === "active" ? "#D1F4E1" : "#F8D7DA",
          color: normalized === "active" ? "#157347" : "#B02A37",
          fontWeight: "500",
          fontSize: "0.75rem",
        }}
      >
        {normalized === "active" ? "Active" : "Inactive"}
      </span>
    );
  };

  // ✅ Subscription Plan — shows plan name + category badge
  const getSubscriptionBadge = (plan, isTrial, planName, planCategory) => {
    // Determine category label and color
    const cat = (planCategory || plan || "").toLowerCase();
    let bg, color, label;
    if (isTrial || cat.includes("trial") || cat.includes("free") || (plan && plan.toLowerCase().includes("trial"))) {
      bg = "#E2F0D9"; color = "#385723"; label = "Trial";
    } else if (cat.includes("premium") || cat.includes("pro")) {
      bg = "#D1F4E1"; color = "#157347"; label = "Premium";
    } else if (cat.includes("growth")) {
      bg = "#FFF3CD"; color = "#856404"; label = "Growth";
    } else if (cat.includes("basic")) {
      bg = "#E8F4FD"; color = "#0969DA"; label = "Basic";
    } else {
      bg = "#F0F0F0"; color = "#555"; label = planCategory || plan || "Basic";
    }
    const displayName = planName || plan || "—";
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
        <span style={{ fontSize: "0.78rem", fontWeight: "600", color: "#333", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "120px" }} title={displayName}>
          {displayName}
        </span>
        <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: bg, color, fontWeight: "600", fontSize: "0.68rem", width: "fit-content" }}>
          {label}
        </span>
      </div>
    );
  };

  // ✅ Expiry Date Badge — shows days remaining or expired
  const getExpiryBadge = (expiryDate) => {
    if (!expiryDate) return <span className="text-muted" style={{ fontSize: "0.78rem" }}>Not Set</span>;
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    const dateStr = expiry.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
    if (diffDays < 0) {
      return (
        <span>
          <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: "#F8D7DA", color: "#B02A37", fontSize: "0.73rem" }}>Expired</span>
          <br/><small className="text-muted" style={{ fontSize: "0.7rem" }}>{dateStr}</small>
        </span>
      );
    } else if (diffDays <= 7) {
      return (
        <span>
          <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: "#FFF3CD", color: "#856404", fontSize: "0.73rem" }}>⚠ {diffDays}d left</span>
          <br/><small className="text-muted" style={{ fontSize: "0.7rem" }}>{dateStr}</small>
        </span>
      );
    } else {
      return (
        <span>
          <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: "#D1F4E1", color: "#157347", fontSize: "0.73rem" }}>Active</span>
          <br/><small className="text-muted" style={{ fontSize: "0.7rem" }}>{dateStr}</small>
        </span>
      );
    }
  };

  const getModalTitle = () => {
    switch (modalType) {
      case "add": return "Add New Admin";
      case "edit": return "Edit Admin";
      case "view": return "Admin Details";
      default: return "Admin Management";
    }
  };

  const handleFormSubmit = async (payload, profileImageFile) => {
    try {
      const formData = new FormData();

      formData.append("fullName", payload.fullName);
      formData.append("email", payload.email);
      formData.append("phone", payload.phone);
      formData.append("roleId", 2);
      formData.append("branchId", payload.branchId || "");
      formData.append("gymName", payload.gymName);
      formData.append("address", payload.address);
      formData.append("planName", payload.planName);
      formData.append("price", payload.planPrice);
      formData.append("duration", payload.planDuration);
      formData.append("description", payload.planDescription);
      formData.append("status", payload.status.toLowerCase());
      formData.append("gstNumber", payload.gstNumber || "");
      formData.append("gymAddress", payload.gymAddress || "");
      formData.append("tax", payload.tax || "18");
      formData.append("subscriptionPlan", payload.subscriptionPlan || "Basic");
      formData.append("licenseExpiryDate", payload.licenseExpiryDate || "");

      if (modalType === "add") {
        formData.append("password", payload.password);
      }

      if (profileImageFile) {
        formData.append("profileImage", profileImageFile);
      }

      const executeRegistration = async (finalFormData) => {
        let response;
        if (modalType === "add") {
          response = await axiosInstance.post("/auth/register", finalFormData, {
            headers: { "Content-Type": "multipart/form-data" },
          });
        } else if (modalType === "edit" && selectedAdmin) {
          response = await axiosInstance.put(`/auth/user/${selectedAdmin.id}`, finalFormData, {
            headers: { "Content-Type": "multipart/form-data" },
          });
        }

        if (response?.data?.success) {
          if (modalType === "add") {
            setAdmins([response.data.user, ...admins]);
            alert("New admin added successfully!");
          } else {
            const updatedAdmins = admins.map((admin) =>
              admin.id === selectedAdmin.id ? response.data.user : admin
            );
            setAdmins(updatedAdmins);
            alert("Admin updated successfully!");
          }
          closeModal();
        } else {
          throw new Error("Operation failed");
        }
      };

      if (modalType === "add" && payload.paymentMethod === "Razorpay") {
        // Razorpay Flow
        const amount = parseFloat(payload.planPrice) || 0;
        if (amount <= 0) {
          alert("Cannot process Razorpay for a 0 amount plan.");
          return;
        }

        const orderRes = await axiosInstance.post("/purchases/create-razorpay-order", { amount });
        if (!orderRes.data.success) {
          throw new Error(orderRes.data.message || "Failed to initialize payment");
        }

        const { order, key, isMock } = orderRes.data;

        if (isMock) {
          formData.append("paymentMethod", "Razorpay");
          formData.append("razorpay_order_id", order.id);
          formData.append("razorpay_payment_id", "pay_mock_" + Date.now());
          formData.append("razorpay_signature", "mock_signature");
          await executeRegistration(formData);
          return;
        }

        const options = {
          key: key,
          amount: order.amount,
          currency: order.currency,
          name: "Gym SaaS Software",
          description: `Admin Subscription: ${payload.planName}`,
          order_id: order.id,
          handler: async function (response) {
            try {
              formData.append("paymentMethod", "Razorpay");
              formData.append("razorpay_order_id", response.razorpay_order_id);
              formData.append("razorpay_payment_id", response.razorpay_payment_id);
              formData.append("razorpay_signature", response.razorpay_signature);
              await executeRegistration(formData);
            } catch (vErr) {
              console.error("Verification error:", vErr);
              alert("Error verifying payment and creating admin.");
            }
          },
          theme: { color: "#6EB2CC" }
        };
        const rzp1 = new window.Razorpay(options);
        rzp1.open();

      } else if (modalType === "add") {
        // Cash Flow
        formData.append("paymentMethod", "Cash");
        formData.append("transactionId", `CASH-${Date.now()}`);
        await executeRegistration(formData);
      } else {
        // Edit mode
        await executeRegistration(formData);
      }
    } catch (error) {
      console.error("Error saving admin:", error);
      alert(`Failed to ${modalType === "add" ? "add" : "update"} admin.`);
    }
  };

  return (
    <div className="container-fluid p-2 p-sm-3 p-md-4">
      {/* HEADER */}
      <div className="row mb-3 mb-md-4 align-items-center">
        <div className="col-12 col-md-8 mb-3 mb-md-0">
          <h2 className="fw-bold fs-4 fs-md-3">Admin Management</h2>
          <p className="text-muted fs-6">Manage all gym admins and their profile details.</p>
        </div>
        <div className="col-12 col-md-4 text-md-end d-flex justify-content-md-end gap-2 align-items-center flex-wrap">
          <div className="dropdown w-100 w-md-auto">
            <button
              className="btn btn-success dropdown-toggle text-white d-flex align-items-center justify-content-center w-100"
              type="button"
              id="exportAdminsDropdown"
              data-bs-toggle="dropdown"
              aria-expanded="false"
              style={{ backgroundColor: "#28a745", border: "none", borderRadius: "10px", fontWeight: 600, padding: "10px 20px", fontSize: "0.9rem" }}
            >
              <i className="bi bi-download me-2"></i>
              Export
            </button>
            <ul className="dropdown-menu shadow-sm" aria-labelledby="exportAdminsDropdown" style={{ borderRadius: "8px", border: "none" }}>
              <li>
                <button className="dropdown-item d-flex align-items-center py-2" onClick={exportAdminsToExcel}>
                  <span style={{ color: "#28a745", marginRight: "10px", fontWeight: 600 }}>XLSX</span> Export to Excel
                </button>
              </li>
              <li>
                <button className="dropdown-item d-flex align-items-center py-2" onClick={exportAdminsToPDF}>
                  <span style={{ color: "#dc3545", marginRight: "10px", fontWeight: 600 }}>PDF</span> Export to PDF
                </button>
              </li>
            </ul>
          </div>
          <button
            className="btn w-100 w-md-auto"
            style={{
              backgroundColor: "#6EB2CC",
              color: "#fff",
              borderRadius: "10px",
              padding: "10px 20px",
              fontWeight: "600",
              fontSize: "0.9rem",
            }}
            onClick={handleAddNew}
            disabled={loading}
          >
            + Add New Admin
          </button>
        </div>
      </div>

      {/* LOADING */}
      {loading ? (
        <div className="text-center py-4">Loading admins...</div>
      ) : (
        <div className="card border-0 shadow-sm" style={{ borderRadius: "16px", background: "#ffffff" }}>
          <div className="card-body p-0">
            {/* DESKTOP TABLE */}
            <div className="table-responsive d-none d-md-block">
              <table className="table align-middle mb-0" style={{ tableLayout: "fixed", width: "100%" }}>
                <colgroup>
                  <col style={{ width: "55px" }} />   {/* PROFILE */}
                  <col style={{ width: "160px" }} />  {/* ADMIN NAME */}
                  <col style={{ width: "110px" }} />  {/* SUBSCRIPTION */}
                  <col style={{ width: "120px" }} />  {/* EXPIRY DATE */}
                  <col style={{ width: "120px" }} />  {/* GYM NAME */}
                  <col style={{ width: "130px" }} />  {/* GST NUMBER */}
                  <col style={{ width: "70px" }} />   {/* TAX */}
                  <col style={{ width: "120px" }} />  {/* CONTACT */}
                  <col style={{ width: "80px" }} />   {/* STATUS */}
                  <col style={{ width: "130px" }} />  {/* ACTIONS */}
                </colgroup>
                <thead style={{ background: "#F8F9FB" }}>
                  <tr>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>PROFILE</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>ADMIN NAME</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>SUBSCRIPTION</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>EXPIRY DATE</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>GYM NAME</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>GST NUMBER</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>TAX</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>CONTACT</th>
                    <th className="py-3" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>STATUS</th>
                    <th className="py-3 text-center" style={{ whiteSpace: "nowrap", fontSize: "0.75rem", color: "#6B7280", fontWeight: "600", letterSpacing: "0.04em" }}>ACTIONS</th>
                  </tr>
                </thead>

                <tbody>
                  {admins.length === 0 ? (
                    <tr>
                      <td colSpan="10" className="text-center text-muted py-4">
                        No admins found
                      </td>
                    </tr>
                  ) : (
                    admins.map((admin) => (
                      <tr
                        key={admin.id}
                        style={{ transition: "0.3s ease" }}
                        onMouseEnter={(e) => (e.currentTarget.style.background = "#F1FBFF")}
                        onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                      >
                        <td className="text-center">
                          <div
                            className="rounded-circle overflow-hidden mx-auto"
                            style={{ width: "40px", height: "40px", border: "1px solid #eee" }}
                          >
                            {admin.profileImage ? (
                              <img
                                src={admin.profileImage.trim()}
                                alt="Profile"
                                className="w-100 h-100 object-fit-cover"
                                onError={(e) => {
                                  e.target.src = '/assets/images/default-avatar.png';
                                }}
                              />
                            ) : (
                              <div className="w-100 h-100 d-flex align-items-center justify-content-center bg-light">
                                <span className="text-muted" style={{ fontSize: '0.65rem' }}>?</span>
                              </div>
                            )}
                          </div>
                        </td>
                        <td style={{ fontSize: "0.855rem", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          <strong style={{ display: "block", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{admin.fullName}</strong>
                          <small className="text-muted" style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", display: "block" }}>{admin.email}</small>
                        </td>
                        <td style={{ fontSize: "0.855rem", minWidth: "130px" }}>{getSubscriptionBadge(admin.subscriptionPlan, admin.isTrial, admin.planDisplayName || admin.planName, admin.planCategory)}</td>
                        <td style={{ fontSize: "0.855rem" }}>{getExpiryBadge(admin.licenseExpiryDate)}</td>
                        <td style={{ fontSize: "0.855rem", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{admin.gymName || "—"}</td>
                        <td style={{ fontSize: "0.78rem", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}><span className="text-muted">{admin.gstNumber || "—"}</span></td>
                        <td style={{ fontSize: "0.855rem" }}><span className="badge bg-info text-dark">{admin.tax || "18"}%</span></td>
                        <td style={{ fontSize: "0.855rem", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{admin.phone || "—"}</td>
                        <td style={{ fontSize: "0.855rem" }}>{getStatusBadge(admin.status)}</td>
                        <td className="text-center">
                          <div className="d-flex justify-content-center gap-1">
                            <button className="btn btn-sm btn-outline-secondary" onClick={() => handleView(admin)} title="View">
                              <FaEye size={13} />
                            </button>
                            <button className="btn btn-sm btn-outline-primary" onClick={() => handleEdit(admin)} title="Edit">
                              <FaEdit size={13} />
                            </button>
                            <button className="btn btn-sm btn-outline-info" onClick={() => handleViewMembers(admin)} title="Members">
                              <FaUser size={13} />
                            </button>
                            <button className="btn btn-sm btn-outline-danger" onClick={() => handleDeleteClick(admin)} title="Delete">
                              <FaTrashAlt size={13} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* MOBILE VIEW */}
            <div className="d-md-none p-3">
              {admins.length === 0 ? (
                <div className="text-center text-muted py-4">No admins found</div>
              ) : (
                admins.map((admin) => (
                  <div key={admin.id} className="card mb-3 shadow-sm" style={{ borderRadius: "12px" }}>
                    <div className="card-body p-3">
                      <div className="d-flex justify-content-between align-items-start mb-2">
                        <h5 className="card-title mb-0 fw-bold">{admin.fullName}</h5>
                        {getStatusBadge(admin.status)}
                      </div>
                      <div className="row g-2 mb-2">
                        <div className="col-6">
                          <small className="text-muted d-block">Gym</small>
                          <span>{admin.gymName || "-"}</span>
                        </div>
                        <div className="col-6">
                          <small className="text-muted d-block">Subscription</small>
                          {getSubscriptionBadge(admin.subscriptionPlan, admin.isTrial, admin.planDisplayName || admin.planName, admin.planCategory)}
                        </div>
                        <div className="col-12 mt-1">
                          <small className="text-muted d-block">Expiry</small>
                          {getExpiryBadge(admin.licenseExpiryDate)}
                        </div>
                      </div>
                      <div className="mb-2">
                        <small className="text-muted d-block">Address</small>
                        <span>{admin.address || "-"}</span>
                      </div>
                      <div className="row g-2 mb-2">
                        <div className="col-6">
                          <small className="text-muted d-block">GST Number</small>
                          <span>{admin.gstNumber || "-"}</span>
                        </div>
                        <div className="col-6">
                          <small className="text-muted d-block">Tax Rate</small>
                          <span className="badge bg-info text-dark">{admin.tax || "18"}%</span>
                        </div>
                      </div>
                      <div className="mb-2">
                        <small className="text-muted d-block">Phone</small>
                        <span>{admin.phone || "-"}</span>
                      </div>
                      <div className="d-flex justify-content-end gap-2">
                        <button className="btn btn-sm btn-outline-secondary" onClick={() => handleView(admin)}>
                          <FaEye size={14} />
                        </button>
                        <button className="btn btn-sm btn-outline-primary" onClick={() => handleEdit(admin)}>
                          <FaEdit size={14} />
                        </button>
                        <button className="btn btn-sm btn-outline-info" onClick={() => handleViewMembers(admin)}>
                          <FaUser size={14} />
                        </button>
                        <button className="btn btn-sm btn-outline-danger" onClick={() => handleDeleteClick(admin)}>
                          <FaTrashAlt size={14} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODALS */}
      {isModalOpen && (
        <ModalWrapper title={getModalTitle()} onClose={closeModal}>
          <AdminForm
            mode={modalType}
            admin={selectedAdmin}
            onCancel={closeModal}
            onSubmit={handleFormSubmit}
            plans={plans}
            loadingPlans={loadingPlans}
            branches={branches}
            loadingBranches={loadingBranches}
          />
        </ModalWrapper>
      )}

      {isDeleteModalOpen && (
        <ModalWrapper title="Confirm Deletion" onClose={closeDeleteModal}>
          <div className="text-center py-4">
            <h5>Are you sure?</h5>
            <p className="text-muted">
              This will permanently delete <strong>{selectedAdmin?.fullName}</strong>.
            </p>
            <div className="d-flex justify-content-center gap-3 mt-4">
              <button className="btn btn-outline-secondary px-4" onClick={closeDeleteModal}>
                Cancel
              </button>
              <button className="btn btn-danger px-4" onClick={confirmDelete}>
                Delete
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}

      {/* 🔹 MEMBERS MODAL */}
      {isMemberModalOpen && (
        <ModalWrapper title={`Members of ${selectedAdmin?.fullName || "Admin"}`} onClose={closeMemberModal}>
          <div className="py-2" style={{ maxHeight: "70vh", maxWidth: "900px", overflowX: "hidden" }}>
            {loadingMembers ? (
              <div className="text-center py-4">Loading members...</div>
            ) : selectedAdminMembers.length === 0 ? (
              <div className="text-center text-muted py-4">No members found</div>
            ) : (
              <div className="row g-3">
                {selectedAdminMembers.map((member) => (
                  <div key={member.id} className="col-12">
                    <div className="d-flex align-items-start p-3 border rounded-3 bg-light">
                      <div
                        className="rounded-circle overflow-hidden flex-shrink-0 me-3"
                        style={{ width: "48px", height: "48px", border: "1px solid #ddd" }}
                      >
                        {member.profileImage ? (
                          <img
                            src={member.profileImage.trim()}
                            alt="Member"
                            className="w-100 h-100 object-fit-cover"
                            onError={(e) => {
                              e.target.src = '/assets/images/default-avatar.png';
                            }}
                          />
                        ) : (
                          <div className="w-100 h-100 d-flex align-items-center justify-content-center bg-secondary text-white">
                            <span className="fw-bold" style={{ fontSize: '0.7rem' }}>
                              {member.fullName.charAt(0).toUpperCase()}
                            </span>
                          </div>
                        )}
                      </div>
                      <div className="flex-grow-1">
                        <div className="d-flex justify-content-between align-items-start">
                          <h6 className="mb-1 fw-bold">{member.fullName}</h6>
                          {getStatusBadge(member.status)}
                        </div>
                        <p className="mb-1 text-muted" style={{ fontSize: '0.875rem' }}>
                          {member.phone} • {member.email}
                        </p>
                        <div className="d-flex flex-wrap gap-2 mt-1">
                          {member.planId && (
                            <span className="badge bg-light text-dark border">Plan ID: {member.planId}</span>
                          )}
                          <span className="badge bg-light text-dark border">
                            Joined: {new Date(member.joinDate).toLocaleDateString()}
                          </span>
                          <span className="badge bg-light text-dark border">{member.gender}</span>
                          {member.interestedIn && (
                            <span className="badge bg-light text-dark border">{member.interestedIn}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          {/* 🔽 Export Buttons */}
          <div className="d-flex justify-content-between align-items-center mt-3 px-3">
            <div>
              <button
                className="btn btn-sm btn-success me-2"
                onClick={exportMembersToExcel}
                disabled={loadingMembers || selectedAdminMembers.length === 0}
              >
                Download Excel
              </button>
              <button
                className="btn btn-sm btn-danger"
                onClick={exportMembersToPDF}
                disabled={loadingMembers || selectedAdminMembers.length === 0}
              >
                Download PDF
              </button>
            </div>
            <button
              className="btn btn-sm btn-outline-secondary"
              onClick={closeMemberModal}
            >
              Close
            </button>
          </div>
        </ModalWrapper>
      )}
    </div>
  );
};

/* ------------------------- MODAL WRAPPER ------------------------- */
const ModalWrapper = ({ title, children, onClose }) => (
  <div
    className="modal fade show"
    style={{ display: "block", background: "rgba(0,0,0,0.5)" }}
    onClick={onClose}
  >
    <div
      className="modal-dialog modal-dialog-centered modal-md"
      style={{ maxWidth: "600px" }}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="modal-content p-0" style={{ borderRadius: "14px" }}>
        <div className="modal-header border-0 py-2 px-3">
          <h5 className="modal-title fw-bold fs-5">{title}</h5>
          <button type="button" className="btn-close" onClick={onClose}></button>
        </div>
        <div className="modal-body p-3">{children}</div>
      </div>
    </div>
  </div>
);

/* --------------------------- ADMIN FORM -------------------------- */
const AdminForm = ({ mode, admin, onCancel, onSubmit, plans, loadingPlans, branches, loadingBranches }) => {
  const isView = mode === "view";
  const isAdd = mode === "add";
  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    fullName: admin?.fullName || "",
    gymName: admin?.gymName || "",
    address: admin?.address || admin?.address_city || "",
    phone: admin?.phone || "",
    email: admin?.email || "",
    password: "",
    status: admin?.status || "active",
    selectedPlanId: "",
    planName: admin?.planName || "",
    planPrice: admin?.price || "",
    planDuration: admin?.duration || "",
    planDescription: admin?.description || "",
    branchId: admin?.branchId || "",
    gstNumber: admin?.gstNumber || "",
    gymAddress: admin?.gymAddress || admin?.address_city || "",
    tax: admin?.tax || "18",
    subscriptionPlan: admin?.subscriptionPlan || "Basic",
    licenseExpiryDate: admin?.licenseExpiryDate
      ? new Date(admin.licenseExpiryDate).toISOString().split("T")[0]
      : "",
    paymentMethod: "Cash",
  });

  const [profileImageFile, setProfileImageFile] = useState(null);
  const [profilePreview, setProfilePreview] = useState(admin?.profileImage || null);

  const [showCropper, setShowCropper] = useState(false);
  const [tempImageSrc, setTempImageSrc] = useState(null);

  useEffect(() => {
    if (admin && plans.length > 0 && admin.planName) {
      let matchedPlan = plans.find(
        (p) => p.name.toLowerCase() === admin.planName.toLowerCase() && p.price.toString() === (admin.price || "").toString()
      );
      if (!matchedPlan) {
        matchedPlan = plans.find((p) => p.name.toLowerCase() === admin.planName.toLowerCase());
      }
      if (matchedPlan) {
        setFormData((prev) => ({ 
          ...prev, 
          selectedPlanId: matchedPlan.id,
          planName: matchedPlan.name,
          planPrice: matchedPlan.price.toString(),
          planDuration: matchedPlan.duration,
          planDescription: matchedPlan.description || prev.planDescription
        }));
      }
    }
    if (admin?.profileImage) {
      setProfilePreview(admin.profileImage);
    } else {
      setProfilePreview(null);
    }
  }, [admin, plans]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handlePlanChange = (planId) => {
    const selectedPlan = plans.find((p) => p.id == planId);
    if (selectedPlan) {
      // 1. Auto-determine the Subscription Tier (Basic, Growth, Premium)
      let subPlan = "Basic";
      const lowPlan = selectedPlan.name.toLowerCase();
      if (lowPlan.includes("trial") || lowPlan.includes("free") || selectedPlan.price == 0) subPlan = "7-Day Trial";
      else if (lowPlan.includes("premium") || lowPlan.includes("pro")) subPlan = "Premium";
      else if (lowPlan.includes("growth")) subPlan = "Growth";

      // 2. Auto-calculate the Expiry Date based on duration string
      const durationStr = selectedPlan.duration ? selectedPlan.duration.toLowerCase() : "";
      const startDate = new Date();
      let expiryDate = new Date(startDate);
      
      if (durationStr.includes("year")) {
         const match = durationStr.match(/(\d+)/);
         const years = match ? parseInt(match[1], 10) : 1;
         expiryDate.setFullYear(expiryDate.getFullYear() + years);
      } else if (durationStr.includes("month")) {
         const match = durationStr.match(/(\d+)/);
         const months = match ? parseInt(match[1], 10) : 1;
         expiryDate.setMonth(expiryDate.getMonth() + months);
      } else if (durationStr.includes("day")) {
         const match = durationStr.match(/(\d+)/);
         const days = match ? parseInt(match[1], 10) : 7;
         expiryDate.setDate(expiryDate.getDate() + days);
      } else {
         // Default fallback to 1 month
         expiryDate.setMonth(expiryDate.getMonth() + 1);
      }

      setFormData((prev) => ({
        ...prev,
        selectedPlanId: planId,
        planName: selectedPlan.name,
        planPrice: selectedPlan.price.toString(),
        planDuration: selectedPlan.duration,
        planDescription: selectedPlan.description || `Plan for ${selectedPlan.duration} @ ₹${selectedPlan.price}`,
        subscriptionPlan: subPlan,
        licenseExpiryDate: expiryDate.toISOString().split("T")[0]
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        selectedPlanId: "",
        planName: "",
        planPrice: "",
        planDuration: "",
        planDescription: "",
        subscriptionPlan: "Basic",
        licenseExpiryDate: ""
      }));
    }
  };

  const handleStatusToggle = () => {
    setFormData((prev) => ({
      ...prev,
      status: prev.status === "active" ? "inactive" : "active",
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      alert("Please upload an image file (JPG, PNG).");
      e.target.value = "";
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      alert("Image size must be less than 5MB.");
      e.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setTempImageSrc(reader.result);
      setShowCropper(true);
    };
    reader.readAsDataURL(file);
  };

  const handleCropComplete = (croppedImage) => {
    // croppedImage = { blob, url }
    if (!croppedImage || !croppedImage.blob) {
      console.error("Crop failed: no blob");
      return;
    }
    const file = new File([croppedImage.blob], "profile.jpg", { type: "image/jpeg" });
    setProfileImageFile(file);
    setProfilePreview(croppedImage.url);
    setShowCropper(false);
    setTempImageSrc(null);
    // reset file input so same file can be re-selected
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSkipCrop = () => {
    // Convert base64 dataURL to File and use directly without cropping
    if (tempImageSrc) {
      try {
        const arr = tempImageSrc.split(",");
        const mimeMatch = arr[0].match(/:(.*?);/);
        const mime = mimeMatch ? mimeMatch[1] : "image/jpeg";
        const bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while (n--) u8arr[n] = bstr.charCodeAt(n);
        const blob = new Blob([u8arr], { type: mime });
        const file = new File([blob], "profile.jpg", { type: mime });
        setProfileImageFile(file);
        setProfilePreview(tempImageSrc);
      } catch (err) {
        console.error("Skip crop error:", err);
      }
    }
    setShowCropper(false);
    setTempImageSrc(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleCropCancel = () => {
    setShowCropper(false);
    setTempImageSrc(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleRemoveImage = () => {
    setProfileImageFile(null);
    setProfilePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isView) return onCancel();
    onSubmit(formData, profileImageFile);
  };

  return (
    <>
      <form onSubmit={handleSubmit}>
      {/* Profile Image */}
      <div className="mb-4 text-center">
        <h6 className="fw-bold mb-2 text-primary">Profile Picture</h6>
        <div
          className="mx-auto rounded-circle overflow-hidden mb-2"
          style={{
            width: "100px",
            height: "100px",
            border: profilePreview ? "3px solid #6EB2CC" : "2px dashed #ccc",
            cursor: !isView ? "pointer" : "default",
            background: "#f8f9fa",
          }}
          onClick={() => !isView && fileInputRef.current?.click()}
        >
          {profilePreview ? (
            <img
              src={profilePreview}
              alt="Profile"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            <div className="w-100 h-100 d-flex flex-column align-items-center justify-content-center">
              <span style={{ fontSize: "1.5rem" }}>📷</span>
              <span className="text-muted" style={{ fontSize: "0.65rem" }}>Click to upload</span>
            </div>
          )}
        </div>
        {!isView && (
          <div>
            <input
              type="file"
              ref={fileInputRef}
              accept="image/jpeg,image/png,image/jpg,image/webp"
              onChange={handleImageChange}
              className="form-control form-control-sm"
              style={{ display: "none" }}
            />
            <div className="d-flex gap-2 justify-content-center mt-1">
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={() => fileInputRef.current?.click()}
                style={{ fontSize: "0.75rem" }}
              >
                {profilePreview ? "Change Photo" : "Choose File"}
              </button>
              {profilePreview && (
                <button
                  type="button"
                  className="btn btn-outline-danger btn-sm"
                  onClick={handleRemoveImage}
                  style={{ fontSize: "0.75rem" }}
                >
                  Remove
                </button>
              )}
            </div>
            <small className="text-muted d-block mt-1">JPG, PNG (Max 5MB)</small>
          </div>
        )}
      </div>

      {/* Personal Info */}
      <div className="mb-4">
        <h6 className="fw-bold mb-3 text-primary">Personal Information</h6>
        <div className="row g-2 mb-3">
          <div className="col-12">
            <label className="form-label fs-6">Full Name *</label>
            <input
              name="fullName"
              className="form-control form-control-sm"
              value={formData.fullName}
              onChange={handleInputChange}
              readOnly={isView}
              required
            />
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label fs-6">Gym Name *</label>
            <input
              name="gymName"
              className="form-control form-control-sm"
              value={formData.gymName}
              onChange={handleInputChange}
              readOnly={isView}
              required
            />
          </div>

          <div className="col-12 col-md-6">
            <label className="form-label fs-6">Phone *</label>
            <input
              name="phone"
              className="form-control form-control-sm"
              value={formData.phone}
              onChange={handleInputChange}
              readOnly={isView}
              required
            />
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label fs-6">Email *</label>
            <input
              name="email"
              type="email"
              className="form-control form-control-sm"
              value={formData.email}
              onChange={handleInputChange}
              readOnly={isView}
              required
            />
          </div>
          <div className="col-12">
            <label className="form-label fs-6">Address *</label>
            <input
              name="address"
              className="form-control form-control-sm"
              value={formData.address}
              onChange={handleInputChange}
              readOnly={isView}
              required
            />
          </div>
        </div>
      </div>

      {/* Gym Information */}
      <div className="mb-4">
        <h6 className="fw-bold mb-3 text-primary">Gym Information</h6>
        <div className="row g-2 mb-3">
          <div className="col-12">
            <label className="form-label fs-6">Gym Address *</label>
            <textarea
              name="gymAddress"
              className="form-control form-control-sm"
              rows="2"
              value={formData.gymAddress}
              onChange={handleInputChange}
              readOnly={isView}
              required
            ></textarea>
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label fs-6">GST Number</label>
            <input
              name="gstNumber"
              className="form-control form-control-sm"
              value={formData.gstNumber}
              onChange={handleInputChange}
              readOnly={isView}
              placeholder="e.g. 29ABCDE1234F1Z5"
            />
          </div>
          <div className="col-12 col-md-6">
            <label className="form-label fs-6">Tax Rate *</label>
            <select
              name="tax"
              className="form-select form-select-sm"
              value={formData.tax}
              onChange={handleInputChange}
              disabled={isView}
              required
            >
              <option value="18">18%</option>
              <option value="5">5%</option>
              <option value="12">12%</option>
              <option value="28">28%</option>
            </select>
          </div>
        </div>
      </div>

      {/* Login Info */}
      {isAdd && (
        <div className="mb-4">
          <h6 className="fw-bold mb-3 text-primary">Login Information</h6>
          <div className="row g-2 mb-3">
            <div className="col-12">
              <label className="form-label fs-6">Password *</label>
              <input
                name="password"
                type="password"
                className="form-control form-control-sm"
                value={formData.password}
                onChange={handleInputChange}
                required
              />
            </div>
          </div>
        </div>
      )}

      {/* Plan Info */}
      <div className="mb-4">
        <h6 className="fw-bold mb-3 text-primary">Plan Information</h6>
        <div className="row g-2 mb-3">
          <div className="col-12">
            <label className="form-label fs-6">Select Plan</label>
            {loadingPlans ? (
              <div className="form-control form-control-sm" disabled>
                Loading plans...
              </div>
            ) : (
              <select
                className="form-select form-select-sm"
                value={formData.selectedPlanId}
                onChange={(e) => handlePlanChange(e.target.value)}
                disabled={isView}
              >
                <option value="">-- Choose Plan --</option>
                {plans.map((plan) => (
                  <option key={plan.id} value={plan.id}>
                    {plan.name} (₹{plan.price}, {plan.duration})
                  </option>
                ))}
              </select>
            )}
          </div>

          {formData.selectedPlanId && (
            <>
              <div className="col-12 col-md-6">
                <label className="form-label fs-6">Price</label>
                <input
                  className="form-control form-control-sm"
                  value={formData.planPrice}
                  readOnly
                />
              </div>
              <div className="col-12 col-md-6">
                <label className="form-label fs-6">Duration</label>
                <input
                  className="form-control form-control-sm"
                  value={formData.planDuration}
                  readOnly
                />
              </div>
              <div className="col-12">
                <label className="form-label fs-6">Description</label>
                <textarea
                  name="planDescription"
                  className="form-control form-control-sm"
                  rows="2"
                  value={formData.planDescription}
                  onChange={handleInputChange}
                  readOnly={isView}
                ></textarea>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Subscription & Expiry */}
      <div className="mb-4">
        <h6 className="fw-bold mb-3 text-primary">Subscription Settings</h6>
        <div className="row g-2">
          <div className="col-12">
            <label className="form-label fs-6">License Expiry Date *</label>
            <input
              type="date"
              name="licenseExpiryDate"
              className="form-control form-control-sm"
              value={formData.licenseExpiryDate}
              onChange={handleInputChange}
              readOnly={isView}
              required
              min={new Date().toISOString().split("T")[0]}
            />
            <small className="text-muted">Date when the subscription will expire.</small>
          </div>
        </div>
      </div>

      {/* Payment Information */}
      {isAdd && (
        <div className="mb-4">
          <h6 className="fw-bold mb-3 text-primary">Payment Information</h6>
          <div className="row g-2">
            <div className="col-12 col-md-6">
              <label className="form-label fs-6">Payment Mode *</label>
              <select
                name="paymentMethod"
                className="form-select form-select-sm"
                value={formData.paymentMethod}
                onChange={handleInputChange}
                required
              >
                <option value="Cash">Cash</option>
                <option value="Razorpay">Razorpay (Online)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Status */}
      <div className="d-flex align-items-center mb-3">
        <label className="form-label me-3 mb-0 fs-6">Status</label>
        <div className="form-check form-switch">
          <input
            type="checkbox"
            className="form-check-input"
            checked={formData.status === "active"}
            onChange={handleStatusToggle}
            disabled={isView}
          />
          <span className="ms-2">{formData.status === "active" ? "Active" : "Inactive"}</span>
        </div>
      </div>

      {/* Buttons */}
      <div className="d-flex justify-content-end gap-2">
        <button type="button" className="btn btn-outline-secondary btn-sm px-3" onClick={onCancel}>
          Close
        </button>
        {!isView && (
          <button
            type="submit"
            className="btn btn-sm px-3"
            style={{ background: "#6EB2CC", color: "#fff" }}
          >
            {mode === "add" ? "Save Admin" : "Update Admin"}
          </button>
        )}
      </div>
      </form>

    {/* Image Cropper rendered OUTSIDE form to avoid form submission conflicts */}
    {showCropper && tempImageSrc && (
      <ImageCropper
        image={tempImageSrc}
        onCropComplete={handleCropComplete}
        onCancel={handleCropCancel}
        onSkip={handleSkipCrop}
      />
    )}
    </>
  );
};

export default SuperAdminAdmin;